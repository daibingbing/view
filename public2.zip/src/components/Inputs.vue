<template>
  <div class='inputs-container'>
    <h1 style='font-size: 14px;font-weight: 500'>{{ t('param') }}</h1>
    <el-row :gutter='10'>
      <el-col :span="12">
        <el-input v-model="store.sdkAppId" placeholder="sdkAppId" type='number'>
          <template #prepend>
            <div class='key'>SDKAppID</div>
          </template>
        </el-input>
      </el-col>
      <el-col :span="12">
        <el-input v-model="store.sdkSecretKey" placeholder="sdkSecretKey" type='string'>
          <template #prepend>
            <div class='key'>sdkSecretKey</div>
          </template>
        </el-input>
      </el-col>
    </el-row>


    <el-row :gutter='10'>
      <el-col :span="12">
        <el-input v-model="store.agentUserId" placeholder="agentUserId">
          <template #prepend>
            <div class='key'>agentUserId</div>
          </template>
        </el-input>
      </el-col>
      <el-col :span="12">
        <el-input v-model="store.role" placeholder="agent / customer">
          <template #prepend>
            <div class='key'>role</div>
          </template>
        </el-input>
      </el-col>
    </el-row>


    <el-row :gutter='10'>
      <el-col :span="12">
        <el-input v-model="store.userId" placeholder="userID">
          <template #prepend>
            <div class='key'>UserID</div>
          </template>
        </el-input>
      </el-col>
      <el-col :span="12">
        <el-input v-model="store.strRoomId" placeholder="roomID(String)">
          <template #prepend>
            <div class='key'>strRoomId</div>
          </template>
        </el-input>
      </el-col>
    </el-row>

    <div class='alert'>
      <el-alert type="error" :closable="false">
        <span class='alert'>{{ t('alert') }} <a target="_blank" :href="t('url')">{{ t('click') }}</a></span>
      </el-alert>
    </div>
  </div>
</template>

<script lang='ts' setup>
import { useI18n } from 'vue-i18n';
import { getParamKey } from '@/utils/utils';
import appStore from '../store/index';

const { t } = useI18n();
const store = appStore();

// 通用邀请链接：URL 仅带坐席 ID 与用户 ID（不带 userSig），进入后根据当前系统 userId 自动鉴权
const agentUserId = getParamKey('agentUserId');
const guestUserId = getParamKey('guestUserId');
const strRoomIdFromUrl = getParamKey('strRoomId');
const sdkAppIdFromUrl = getParamKey('sdkAppId');
const sdkSecretKeyFromUrl = getParamKey('sdkSecretKey');

const CURRENT_USER_BY_ROOM_KEY = 'imAndVideo_user_';

if (agentUserId && guestUserId && strRoomIdFromUrl) {
  store.pendingInvite = {
    agentUserId,
    guestUserId,
    strRoomId: strRoomIdFromUrl,
    sdkAppId: sdkAppIdFromUrl || String(store.sdkAppId),
  };
  store.sdkAppId = Number(sdkAppIdFromUrl) || store.sdkAppId;
  store.strRoomId = strRoomIdFromUrl;
  store.autoEnter = getParamKey('autoEnter') === '1' || store.autoEnter;
  if (sdkSecretKeyFromUrl) {
    store.sdkSecretKey = sdkSecretKeyFromUrl;
  }
  // 根据当前系统 userId（按房间存储）自动鉴权：若本机曾选过该房间身份则直接应用
  const currentUserForRoom = typeof localStorage !== 'undefined'
    ? localStorage.getItem(CURRENT_USER_BY_ROOM_KEY + strRoomIdFromUrl)
    : null;
  if (currentUserForRoom === agentUserId) {
    store.applyInviteAsAgent();
  } else if (currentUserForRoom === guestUserId) {
    store.applyInviteAsGuest();
  }
  // 否则保留 pendingInvite，由首页选择身份
} else {
  store.$patch({
    sdkAppId: store.sdkAppId,
    sdkSecretKey: store.sdkSecretKey,
    agentUserId: getParamKey('agentUserId'),
    userId: getParamKey('userId'),
    strRoomId: getParamKey('strRoomId'),
    role: getParamKey('role') || store.role || 'agent',
    autoEnter: getParamKey('autoEnter') === '1' || store.autoEnter,
  });
}

const state = { url: window.location.href.split('?')[0] };
window.history.pushState(state, '', 'index.html#/');

</script>

<style lang='stylus' scoped>
.el-row
  margin-bottom 10px
.key
  width 80px
  color #212529
.alert
  font-size 14px !important
  padding 10px 0
</style>
