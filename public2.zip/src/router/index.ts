import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router';
import Index from '../views/Index.vue';

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'home',
    component: Index,
  },
  {
    path: '/create-room',
    name: 'createRoom',
    component: () => import('../views/CreateRoom.vue'),
  },
  {
    path: '/invite',
    name: 'invite',
    component: () => import(/* webpackChunkName: "invite" */ '../views/Invite.vue'),
  },
  {
    path: '/im',
    name: 'im',
    component: () => import(/* webpackChunkName: "im" */ '../views/im/im.vue'),
  },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

export default router;
