<template>
  <div class="im-panel">
    <IMStatus :sdk-ready="sdkReady" :login-status="loginStatus" :user-id="userId" />
    <!-- <p>目前只有user1和user2两个账号，请选择对应的账号进行登录，后续是通过url与当前用户进行判断，当前用户是否坐席对端用户 ID就是用户，用户则相反</p> -->
    <div v-if="!loginStatus" class="login-section">
      <h3 class="section-title">聊天登录</h3>
      <div class="input-group">
        <select v-model="loginUserId" class="select">
          <option disabled value="">选择角色对应账号</option>
          <option v-for="user in testUsers" :key="user.userId" :value="user.userId">
            {{ user.name }} ({{ user.userId }})
          </option>
        </select>
        <select v-model="loginUserSig" class="select">
          <option disabled value="">选择测试 userSig</option>
          <option v-for="user in testUsers" :key="user.userId + '-sig'" :value="user.userSig">
            {{ user.name }}
          </option>
        </select>
        <button class="btn btn-primary" :disabled="!loginUserId || !loginUserSig" @click="handleLogin">
          登录
        </button>
      </div>
      <p class="note">当前业务房间：{{ roomId || '-' }}，实际项目中 userSig 应由服务端生成</p>
    </div>

    <div v-else class="chat-section">
      <div class="chat-header">
        <div class="chat-title">
          <span class="badge">{{ roleLabel }}</span>
          <span class="room-text">房间：{{ roomId || '-' }}</span>
        </div>
        <button class="btn btn-secondary" @click="handleLogout">退出聊天</button>
      </div>

      <div class="chat-main">
        <div class="message-input">
          <input v-model="targetUserId" type="text" placeholder="对端用户 ID" class="input small" />
          <input v-model="messageContent" type="text" placeholder="输入消息，回车发送" class="input"
            @keyup.enter="sendTextMessage" />
          <button class="btn btn-primary" :disabled="!targetUserId || !messageContent" @click="sendTextMessage">
            发送
          </button>
        </div>

        <div class="message-list">
          <div v-for="(msg, index) in messageList" :key="index" :class="['message-item', msg.direction]">
            <div class="meta">
              <span class="from">{{ msg.from }}</span>
              <span class="time">{{ msg.time }}</span>
            </div>
            <div class="content">
              {{ msg.content }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, onMounted, onUnmounted, computed } from 'vue';
import IMStatus from '@/views/im/IMStatus.vue';
import {
  initTIM,
  loginTIM,
  logoutTIM,
  sendTextMsg,
  onMessageReceived,
  offMessageReceived,
  TIM,
} from '@/utils/tim';

const props = defineProps<{
  role: string;
  roomId: string;
}>();

const sdkReady = ref(false);
const loginStatus = ref(false);
const userId = ref('');
const messageList = ref<any[]>([]);

const loginUserId = ref('');
const loginUserSig = ref('');
const targetUserId = ref('');
const messageContent = ref('');

const testUsers = ref([
  {
    userId: 'user1',
    name: '坐席账号(user1)',
    userSig:
      'eJw1zF0LgjAYBeD-suuQd6ttKnRZWAlBZdSlto-eIhvOTIj*e6Z1eZ5zOC*yS7dBoysSExYAGfUZlS5rNNjzw*uK-gqvrrlzqEhMBQBlEyHF0OjWYaU755wzABi0xtvXpIh4KKL-1qPtfpNLWTRtws3BLiXS8Tq081nmTL4-09PzqP09tZncrPwCpuT9ASnZMaA_',
  },
  {
    userId: 'user2',
    name: '客户账号(user2)',
    userSig:
      'eJyrVgrxCdYrSy1SslIy0jNQ0gHzM1NS80oy0zLBwqXFqUVGUInilOzEgoLMFCUrQzMDA0MjEzNzM4hMakVBZlEqUNzU1NTIwMAAIlqSmQsSMzezNLUwh4sWZ6YDzc3wiNGvsDR1dNcurwrOzggy0a7wTHdOrSpzSQ8INElNcY30tHA2qsrLDPJItlWqBQBGHzF9',
  },
]);

const logs = ref<{ time: string; content: string; type: string }[]>([]);

const roleLabel = computed(() => {
  if (props.role === 'customer') return '客户';
  if (props.role === 'agent') return '坐席';
  return props.role || '未知角色';
});

function addLog(content: string, type = 'info') {
  const time = new Date().toLocaleTimeString();
  logs.value.unshift({ time, content, type });
  // 控制台简单输出，方便调试
  // eslint-disable-next-line no-console
  console.log(`[${type.toUpperCase()}] ${content}`);
}

const normalizeMessage = (message: any) => {
  const base = {
    from: message.from,
    to: message.to,
    time: new Date().toLocaleTimeString(),
    direction: message.from === userId.value ? 'outgoing' : 'incoming',
  };
  const p = message.payload || {};
  const textContent = p.text || p.description || p.data || '未知消息类型';
  return {
    ...base,
    type: 'text',
    content: typeof textContent === 'string' ? textContent : String(textContent),
  };
};

const handleNewMessage = (event: any) => {
  event.data.forEach((message: any) => {
    const newMsg = normalizeMessage(message);
    messageList.value.push(newMsg);
    addLog(`收到消息: ${message.from} -> ${message.to}: ${newMsg.content}`, 'message');
  });
};

const initSDK = async () => {
  try {
    const tim = await initTIM({
      SDKAppID: 1600124676,
      level: 0,
    });
    tim.on(TIM.EVENT.SDK_READY, () => {
      sdkReady.value = true;
      addLog('IM SDK 准备就绪', 'success');
    });
    tim.on(TIM.EVENT.SDK_NOT_READY, () => {
      sdkReady.value = false;
      addLog('IM SDK 未就绪', 'warning');
    });
  } catch (error: any) {
    addLog(`SDK 初始化失败: ${error.message}`, 'error');
  }
};

const handleLogin = async () => {
  if (!loginUserId.value || !loginUserSig.value) {
    addLog('请输入 / 选择登录账号和 userSig', 'warning');
    return;
  }
  try {
    await loginTIM({
      userID: loginUserId.value,
      userSig: loginUserSig.value,
    });
    loginStatus.value = true;
    userId.value = loginUserId.value;
    messageList.value = [];
    addLog(`用户 ${loginUserId.value} 登录 IM 成功`, 'success');
    onMessageReceived(handleNewMessage);
  } catch (error: any) {
    addLog(`登录失败: ${error.message}`, 'error');
  }
};

const handleLogout = async () => {
  try {
    offMessageReceived(handleNewMessage);
    await logoutTIM();
    loginStatus.value = false;
    userId.value = '';
    messageList.value = [];
    addLog('退出聊天成功', 'info');
  } catch (error: any) {
    addLog(`退出聊天失败: ${error.message}`, 'error');
  }
};

const sendTextMessage = async () => {
  if (!targetUserId.value || !messageContent.value) {
    addLog('请输入接收方和消息内容', 'warning');
    return;
  }
  try {
    await sendTextMsg({
      to: targetUserId.value,
      text: messageContent.value,
    });
    messageList.value.push({
      from: userId.value,
      to: targetUserId.value,
      content: messageContent.value,
      time: new Date().toLocaleTimeString(),
      direction: 'outgoing',
      type: 'text',
    });
    addLog(`发送消息给 ${targetUserId.value}: ${messageContent.value}`, 'message');
    messageContent.value = '';
  } catch (error: any) {
    addLog(`发送消息失败: ${error.message}`, 'error');
  }
};

onMounted(async () => {
  await initSDK();
  // 根据传入角色自动预选账号并尝试自动登录
  const preset =
    props.role === 'customer'
      ? testUsers.value[1] || testUsers.value[0]
      : testUsers.value[0];
  if (preset) {
    loginUserId.value = preset.userId;
    loginUserSig.value = preset.userSig;
    // 自动登录，进入首页即可完成 IM 鉴权
    await handleLogin();
  }
});

onUnmounted(() => {
  if (loginStatus.value) {
    handleLogout();
  }
});
</script>

<style scoped>
.im-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  background-color: #ffffff;
  padding: 12px;
}

.login-section,
.chat-section {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.section-title {
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 8px;
}

.input-group {
  display: flex;
  gap: 8px;
  margin-bottom: 6px;
  flex-wrap: wrap;
}

.select,
.input {
  flex: 1;
  min-width: 120px;
  padding: 6px 10px;
  border-radius: 4px;
  border: 1px solid #d1d5db;
  font-size: 12px;
}

.input.small {
  max-width: 120px;
}

.btn {
  padding: 6px 10px;
  border-radius: 4px;
  border: none;
  font-size: 12px;
  cursor: pointer;
  white-space: nowrap;
}

.btn-primary {
  background: #2563eb;
  color: #fff;
}

.btn-secondary {
  background: #6b7280;
  color: #fff;
}

.note {
  font-size: 11px;
  color: #6b7280;
}

.chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
}

.chat-title {
  display: flex;
  align-items: center;
  gap: 6px;
}

.badge {
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 999px;
  background-color: #eff6ff;
  color: #1d4ed8;
}

.room-text {
  font-size: 11px;
  color: #4b5563;
}

.chat-main {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.message-input {
  display: flex;
  gap: 6px;
  margin-bottom: 6px;
}

.message-list {
  flex: 1;
  padding: 6px;
  border-radius: 4px;
  background-color: #f9fafb;
  overflow-y: auto;
}

.message-item {
  margin-bottom: 6px;
  padding: 4px 6px;
  border-radius: 4px;
  font-size: 12px;
}

.message-item.incoming {
  background-color: #e0f2fe;
}

.message-item.outgoing {
  background-color: #dcfce7;
}

.meta {
  display: flex;
  justify-content: space-between;
  margin-bottom: 2px;
}

.from {
  font-weight: 500;
  color: #111827;
}

.time {
  font-size: 10px;
  color: #6b7280;
}
</style>
