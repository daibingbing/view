import { defineStore } from 'pinia';
import { genTestUserSig } from '../utils/generateTestUserSig';

const appStore = defineStore('app', {
  state: () => ({
    sdkAppId: 1600077738,
    userId: '',
    strRoomId: '',
    sdkSecretKey: 'fc59223c930fd14c91ce62fd0c0666c2e9fcc6a5b4efe933fc1973404e532493',
    userSig: '',
    audioDeviceId: '',
    videoDeviceId: '',
    cameraList: [],
    microphoneList: [],
    logs: [],
    remoteUsersViews: [],
    invitedRemoteUsers: [],
    // 业务相关：角色与预约时间
    // role: 'agent' 表示坐席（创建者），'customer' 表示被邀请用户
    role: 'agent',
    // role: 'agent' 表示坐席（创建者），'customer' 表示被邀请用户
    agentUserId:'',
    // 是否在进入首页时自动进房
    autoEnter: false,
    // 通用邀请链接解析出的待选身份（仅坐席 ID + 用户 ID，无 userSig，进入后根据当前系统 userId 自动鉴权）
    pendingInvite: null as {
      agentUserId: string;
      guestUserId: string;
      strRoomId: string;
      sdkAppId: string;
    } | null,
  }),
  getters: {},
  actions: {
    getInitParamsStates() {
      return !!(this.sdkAppId && this.strRoomId && this.userId && (this.sdkSecretKey || this.userSig));
    },
    getUserSig() {
      return this.userSig || genTestUserSig({
        sdkAppId: Number(this.sdkAppId),
        userId: this.userId,
        sdkSecretKey: this.sdkSecretKey,
      }).userSig;
    },

    /**
     * 生成通用邀请链接：URL 仅带坐席 ID 与用户 ID（不带 userSig），进入页面后根据当前系统 userId 自动鉴权
     */
    createShareLink() {
      const { origin } = window.location;
      const { pathname } = window.location;
      const params = new URLSearchParams();
      params.append('strRoomId', this.strRoomId);
      params.append('SDKAppId', String(this.sdkAppId));
      params.append('agentUserId', this.agentUserId);
      params.append('guestUserId', this.userId);
      params.append('autoEnter', '1');
      return `${origin}${pathname}#/?${params.toString()}`;
    },

    /** 以坐席身份应用邀请：使用 URL 中的坐席 ID，userSig 由当前 sdkSecretKey 自动生成 */
    applyInviteAsAgent() {
      const p = this.pendingInvite;
      if (!p) return;
      this.userId = p.agentUserId;
      this.userSig = '';
      this.role = 'agent';
      this.strRoomId = p.strRoomId;
      this.sdkAppId = Number(p.sdkAppId) || this.sdkAppId;
      this.pendingInvite = null;
    },

    /** 以客户身份应用邀请：使用 URL 中的用户 ID，userSig 由当前 sdkSecretKey 自动生成 */
    applyInviteAsGuest() {
      const p = this.pendingInvite;
      if (!p) return;
      this.userId = p.guestUserId;
      this.userSig = '';
      this.role = 'customer';
      this.strRoomId = p.strRoomId;
      this.sdkAppId = Number(p.sdkAppId) || this.sdkAppId;
      this.pendingInvite = null;
    },
    addSuccessLog(str: string) {
      this.logs.push({
        type: 'success',
        content: str,
      });
    },
    addFailedLog(str: string) {
      this.logs.push({
        type: 'failed',
        content: str,
      });
    },
  },
});

export default appStore;
