<template>
  <el-row style="padding: 0 10px 40px 10px">
    <el-col :md="{ span: 18, offset: 3 }" :sm="{ span: 24 }">
      <h2 class="page-title">创建视频客服房间</h2>

      <p class="page-desc">
        配置基础参数和预约时间，点击“生成邀请链接”。<br />
        坐席与客户均使用该链接进入，打开后选择身份（坐席 / 客户），系统根据选择完成视频与 IM 鉴权。
      </p>

      <Inputs />



      <div class="btn-line">
        <el-button type="primary" @click="handleCreate">
          生成邀请链接
        </el-button>
      </div>

      <div v-if="inviteLink" class="share-block">
        <div class="share-title">通用邀请链接（坐席与客户均点此链接，进入后选择身份）</div>
        <el-input v-model="inviteLink" readonly />
      </div>
    </el-col>
  </el-row>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue';
import { ElMessage } from 'element-plus';
import Inputs from '@/components/Inputs.vue';
import appStore from '@/store/index';

const store = appStore();
const inviteLink = ref('');

onMounted(() => {
  store.role = 'agent';
});

function handleCreate() {
  if (!store.sdkAppId || !store.sdkSecretKey || !store.userId || !store.strRoomId) {
    ElMessage.error('请先完整填写 SDKAppId、SDKSecretKey、UserID、strRoomId');
    return;
  }

  inviteLink.value = store.createShareLink();
  ElMessage.success('邀请链接已生成，坐席与客户均使用该链接进入，打开后选择身份');
}
</script>

<style lang="scss" scoped>
.page-title {
  font-size: 18px;
  font-weight: 600;
  margin: 10px 0 8px;
}

.page-desc {
  font-size: 13px;
  color: #6b7280;
  margin-bottom: 16px;
  line-height: 1.6;
}

.form-extra {
  margin-top: 10px;
}

.btn-line {
  margin-top: 16px;
}

.share-block {
  margin-top: 16px;
  padding: 12px;
  border: 1px solid #e5e7eb;
  border-radius: 6px;
  background: #f9fafb;
}

.share-title {
  font-size: 13px;
  margin-bottom: 6px;
}
</style>
